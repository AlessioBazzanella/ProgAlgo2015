Per ogni file di input c'è il corrispondente file di output contenente la risposta corretta.
Questi dati sono stati generati con lo stesso algoritmo di quelli su judge, ma con un diverso seme per il generatore di numeri casuali.
